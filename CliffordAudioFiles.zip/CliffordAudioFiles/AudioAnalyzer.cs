using UnityEngine;
using TMPro;

[RequireComponent(typeof(AudioSource))]
public class AudioAnalyzerMultiChannel : MonoBehaviour //place this script on an audio source
{
    public int sampleSize = 1024; //power of two
    public float amplitudeGain = 100f;

    [SerializeField] TMP_Text bassText;
    [SerializeField] TMP_Text midText;
    [SerializeField] TMP_Text trebleText;
    [SerializeField] TMP_Text spectralText;

    [Header("Expected Input Ranges")]
    [Header("Bass Energy (A)")]
    public float inputMinA = 0f;
    public float inputMaxA = 1f;
    [Header("Mid Energy (B)")]
    public float inputMinB = 0f;
    public float inputMaxB = 1f;
    [Header("Treble Energy (C)")]
    public float inputMinC = 0f;
    public float inputMaxC = 1f;
    [Header("Absolute Spectral Flux (D)")]
    public float inputMinD = 0f;
    public float inputMaxD = 1f;

    private AudioSource audioSource;
    private float[] samples;
    private float[] spectrum;
    private float[] previousSpectrum;
    private float bassEnergy;
    private float midEnergy;
    private float trebleEnergy;
    private float spectralFlux;

    private CliffordManager cliffordManager;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        cliffordManager = FindObjectOfType<CliffordManager>();
        samples = new float[sampleSize];
        spectrum = new float[sampleSize];
        previousSpectrum = new float[sampleSize];
    }

    void Update()
    {
        if (!audioSource.isPlaying) return;

        Analyze();
        UpdateCliffordValues();
        DebugAudioInfo();
    }

    void Analyze()
    {
        audioSource.GetOutputData(samples, 0);
        audioSource.GetSpectrumData(spectrum, 0, FFTWindow.BlackmanHarris);

        bassEnergy = SumBinsInRange(spectrum, 20f, 250f);
        midEnergy = SumBinsInRange(spectrum, 250f, 2000f);
        trebleEnergy = SumBinsInRange(spectrum, 2000f, AudioSettings.outputSampleRate / 2f);

        spectralFlux = ComputeAbsoluteSpectralFlux(spectrum, previousSpectrum);
        System.Array.Copy(spectrum, previousSpectrum, spectrum.Length);
    }

    float SumBinsInRange(float[] spec, float freqMin, float freqMax)
    {
        float sum = 0f;
        int n = spec.Length;
        float binSize = AudioSettings.outputSampleRate / 2f / n;
        for (int i = 0; i < n; i++)
        {
            float freq = i * binSize;
            if (freq >= freqMin && freq < freqMax)
                sum += spec[i];
        }
        return sum * amplitudeGain;
    }

    float ComputeAbsoluteSpectralFlux(float[] current, float[] previous)
    {
        float flux = 0f;
        for (int i = 0; i < current.Length; i++)
        {
            flux += Mathf.Abs(current[i] - previous[i]);
        }
        return flux * amplitudeGain;
    }

    void UpdateCliffordValues()
    {
        cliffordManager.SetA(bassEnergy, inputMinA, inputMaxA);
        cliffordManager.SetB(midEnergy, inputMinB, inputMaxB);
        cliffordManager.SetC(trebleEnergy, inputMinC, inputMaxC);
        cliffordManager.SetD(spectralFlux, inputMinD, inputMaxD);

        /*bassText.text = bassEnergy.ToString(); //optional debugging
        midText.text = midEnergy.ToString();
        trebleText.text = trebleEnergy.ToString();
        spectralText.text = spectralFlux.ToString(); */
    }

    void DebugAudioInfo()
    {
        string info = "Audio Analysis:\n" +
                      $"Bass Energy:        {bassEnergy:F4}\n" +
                      $"Mid Energy:         {midEnergy:F4}\n" +
                      $"Treble Energy:      {trebleEnergy:F4}\n" +
                      $"Abs Spectral Flux:  {spectralFlux:F4}\n" +
                      $"Time: {audioSource.time:F1}s / {audioSource.clip.length:F1}s";
        Debug.Log(info);
    }
}
