using UnityEngine;

[ExecuteInEditMode]
public class CliffordManager : MonoBehaviour //place this on a camera and then assign reference to the CliffordAttrator shader
{
    public ComputeShader attractorShader;
    public int textureSize = 512;

    [Header("Clifford Parameters")]
    [Header("a")]
    public float a = 1.5f;
    public float aMin = -2f;
    public float aMax = 2f;

    [Header("b")]
    public float b = -1.8f;
    public float bMin = -2f;
    public float bMax = 2f;

    [Header("c")]
    public float c = 1.6f;
    public float cMin = -2f;
    public float cMax = 2f;

    [Header("d")]
    public float d = 0.9f;
    public float dMin = -2f;
    public float dMax = 2f;

    [Header("Smoothing")]
    public float lerpDuration = 0.1f;
    [Range(0f, 1f)] public float dampening = 1f;

    [Header("Iterations")]
    public int iterations = 50000;
    [Header("Mapping")]
    public Vector2 mapRange = new Vector2(2f, 2f);
    public Vector2 mapOffset = new Vector2(0.5f, 0.5f);

    [Header("Colors")]
    [GradientUsage(true)] public Gradient colorGradient;

    ComputeBuffer densityBuffer;
    Texture2D displayTex;

    //smoothing targets
    float targetA, targetB, targetC, targetD;

    void OnDisable()
    {
        if (densityBuffer != null) densityBuffer.Release();
    }

    void Init()
    {
        int count = textureSize * textureSize;
        if (densityBuffer == null || densityBuffer.count != count)
        {
            if (densityBuffer != null) densityBuffer.Release();
            densityBuffer = new ComputeBuffer(count, sizeof(uint));
        }

        if (displayTex == null || displayTex.width != textureSize)
        {
            displayTex = new Texture2D(textureSize, textureSize, TextureFormat.RGBAFloat, false);
        }

        if (colorGradient == null)
        {
            colorGradient = new Gradient();
            colorGradient.SetKeys(
                new GradientColorKey[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.red, 1f) },
                new GradientAlphaKey[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(1f, 1f) }
            );
        }

        targetA = a;
        targetB = b;
        targetC = c;
        targetD = d;
    }

    void Update()
    {
        if (lerpDuration > 0f)
        {
            float alpha = Time.deltaTime / lerpDuration * dampening;
            a = Mathf.Lerp(a, targetA, alpha);
            b = Mathf.Lerp(b, targetB, alpha);
            c = Mathf.Lerp(c, targetC, alpha);
            d = Mathf.Lerp(d, targetD, alpha);
        }
        else
        {
            a = targetA;
            b = targetB;
            c = targetC;
            d = targetD;
        }
    }

    void OnRenderImage(RenderTexture src, RenderTexture dst)
    {
        if (attractorShader == null)
        {
            Graphics.Blit(src, dst);
            return;
        }

        Init();

        uint[] zeros = new uint[textureSize * textureSize];
        densityBuffer.SetData(zeros);

        int kernel = attractorShader.FindKernel("CSMain");
        attractorShader.SetBuffer(kernel, "Density", densityBuffer);
        attractorShader.SetInt("width", textureSize);
        attractorShader.SetInt("height", textureSize);
        attractorShader.SetInt("iterations", iterations);

        //clamps
        attractorShader.SetFloat("a", Mathf.Clamp(a, aMin, aMax));
        attractorShader.SetFloat("b", Mathf.Clamp(b, bMin, bMax));
        attractorShader.SetFloat("c", Mathf.Clamp(c, cMin, cMax));
        attractorShader.SetFloat("d", Mathf.Clamp(d, dMin, dMax));

        attractorShader.SetFloats("mapRange", mapRange.x, mapRange.y);
        attractorShader.SetFloats("mapOffset", mapOffset.x, mapOffset.y);

        int groups = Mathf.CeilToInt(textureSize / 8f);
        attractorShader.Dispatch(kernel, groups, groups, 1);

        uint[] counts = new uint[textureSize * textureSize];
        densityBuffer.GetData(counts);

        Color[] cols = new Color[counts.Length];
        uint max = 1;
        foreach (var v in counts) if (v > max) max = v;

        for (int i = 0; i < cols.Length; i++)
        {
            float t = Mathf.Clamp01(counts[i] / (float)max);
            cols[i] = colorGradient.Evaluate(t);
        }

        displayTex.SetPixels(cols);
        displayTex.Apply();

        Graphics.Blit(displayTex, dst);
    }

    float RemapToUnit(float value, float inMin, float inMax)
    {
        if (Mathf.Approximately(inMin, inMax))
            return 0f; // avoid div0
        return Mathf.Clamp01((value - inMin) / (inMax - inMin));
    }

    public void SetA(float inputValue, float expectedMin, float expectedMax)
    {
        float t = RemapToUnit(inputValue, expectedMin, expectedMax);
        float desired = Mathf.Lerp(aMin, aMax, t);
        targetA = Mathf.Lerp(a, desired, dampening);
    }

    public void SetB(float inputValue, float expectedMin, float expectedMax)
    {
        float t = RemapToUnit(inputValue, expectedMin, expectedMax);
        float desired = Mathf.Lerp(bMin, bMax, t);
        targetB = Mathf.Lerp(b, desired, dampening);
    }

    public void SetC(float inputValue, float expectedMin, float expectedMax)
    {
        float t = RemapToUnit(inputValue, expectedMin, expectedMax);
        float desired = Mathf.Lerp(cMin, cMax, t);
        targetC = Mathf.Lerp(c, desired, dampening);
    }

    public void SetD(float inputValue, float expectedMin, float expectedMax)
    {
        float t = RemapToUnit(inputValue, expectedMin, expectedMax);
        float desired = Mathf.Lerp(dMin, dMax, t);
        targetD = Mathf.Lerp(d, desired, dampening);
    }
}
